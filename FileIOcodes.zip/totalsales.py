# want to read line by line data from a file and accumulate total amount

salesfile = open('sales.txt','r')
totalamount = 0.0
line = salesfile.readline()
while (line != ''):
    totalamount = totalamount + float(line)

    line = salesfile.readline()

print("The total sale amount is : ", totalamount)

salesfile.close()
