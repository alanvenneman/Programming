infile = open('mydata.txt','r')

file_contents = infile.read()

print(file_contents)

infile.close()

outfile = open('mydata2.txt','w')

outfile.write(file_contents)

outfile.close()

