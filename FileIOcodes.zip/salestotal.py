# want to read each data line and accumulate a total

salesfile = open('sales.txt','r')
totalamount = 0.0
line = salesfile.readline()
while line != '':
    amount = float(line)
    totalamount = totalamount + amount
    line = salesfile.readline()
print("The Total sales Amount is :", totalamount)
salesfile.close()


