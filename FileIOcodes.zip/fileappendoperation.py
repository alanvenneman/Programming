appendfile = open('mydata2.txt','a')

appendfile.write("This is my appended data at the bottom of the file\n")

appendfile.close()
