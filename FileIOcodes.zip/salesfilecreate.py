salesfile = open('sales.txt','w')

sales = 0.0
print("Please enter the sales, -1 to finish")
while (sales != -1):
    sales = float(input("Enter sales :"))
    if (sales != -1):
        salesfile.write(str(sales) + '\n')

print("Created a sales files, Thanks ")
salesfile.close()

